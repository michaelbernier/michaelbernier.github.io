#!/usr/bin/env python

import vtk

def main():
    

    ### SOURCE

    cube = vtk.vtkCubeSource()

    ### FILTER (none)

    ### MAPPING
 
    cube_mapper = vtk.vtkPolyDataMapper()
    cube_mapper.SetInputConnection(cube.GetOutputPort())

    ### ACTOR (link mapper to renderer)
    cube_actor = vtk.vtkActor()
    cube_actor.SetMapper(cube_mapper)
    cube_actor.GetProperty().SetColor(1.0, 0.0, 0.0)

    ### RENDERING
    renderer = vtk.vtkRenderer()
    renderer.SetBackground(1.0, 1.0, 1.0)
    renderer.AddActor(cube_actor)
 
    
    ### RENDERING WINDOW
    render_window = vtk.vtkRenderWindow()
    render_window.SetWindowName("IMN430")
    render_window.SetSize(400, 400)
    render_window.AddRenderer(renderer)
 

    ### RENDERING INTERECTOR
    interactor = vtk.vtkRenderWindowInteractor()
    interactor.SetRenderWindow(render_window)

    # Initialize the interactor and start the
    # rendering loop
    interactor.Initialize()
    render_window.Render()
    interactor.Start()
 
main()